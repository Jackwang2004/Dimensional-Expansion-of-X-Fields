import argparse
import numpy as np
import cv2,os,json


def load_imgs(args):

    print("Dataset path: %s"%(args.dataset))
    path_images = os.path.join(args.dataset, "images")
    images = os.listdir(path_images)

    img =  cv2.imread(os.path.join(path_images, images[0]))
    h_res,w_res,_ = img.shape
    h_res = h_res//args.factor
    w_res = w_res//args.factor
    num_n = args.num_n

    print('Downsampling factor: %d'%(args.factor))
    print('Output resolution: %d x %d'%(h_res,w_res))
    dims = args.dim

    path = os.path.join(args.dataset, "details.log")
    details = open(path)

    coordinates = []
    all_pairs = []
    images  = []

    controls = ['CameraControl.view_point_x', 'CameraControl.view_point_y', 'CameraControl.view_point_z' ]
    boatmodel = "tugboat_1.blend"

    num_n = min(np.prod(dims), num_n)

    k = 0
    for object in details:
        line = json.loads(object)
        if line.get("model") == boatmodel:
            k += 1
            print('\r Reading image %d out of %d '%(k, np.prod(dims)), end=" " )

            # images
            id = line.get("id")
            img =  cv2.imread(os.path.join(path_images, id+"_rgb.png"))
            img = cv2.resize(img,None,fx=1/args.factor,fy=1/args.factor, interpolation = cv2.INTER_AREA)
            img = np.float32(img)/255.0
            images.append(img)

            # coordinates
            coorddict = line.get("render_args")
            coordinate = []
            for control in controls:
                coordinate.append(coorddict.get(control))
            coordinates.append(np.array(coordinate))

            #DEBUGGED, WORKS


    coordinates = np.stack(coordinates, 0)
    coordinates = np.expand_dims(coordinates, 1)
    coordinates = np.expand_dims(coordinates, 1)
    for i in range(coordinates.shape[0]):
        dist = np.sum(np.square(coordinates[i,0,0,:] - coordinates[:,0,0,:]), -1)
        idx = np.argsort(dist)[:num_n+1]
        all_pairs.append(idx)

 

    images = np.stack(images, 0)
    all_pairs = np.array(all_pairs)

    print(images.shape, coordinates.shape, all_pairs.shape)

    return images,coordinates,all_pairs,h_res,w_res
